//wkwkwk ty technoskill 1.0

const pg = require("./connect");

exports.getAll = async function getAll(req, res) {
    try {
        const result = await pg.query('SELECT * FROM stores');
        res.status(200).json(result.rows);
    } catch (error) {
        console.error('Error fetching stores:', error);
        res.status(500).json({ message: 'Internal Server Error' });
    }
}

exports.create = async function create(req, res) {
    const { name, address } = req.body;

    if (!name || !address) {
        return res.status(400).json({ message: 'Name and address are required' });
    }

    try {
        const result = await pg.query(
            'INSERT INTO stores(name, address) VALUES($1, $2) RETURNING *',
            [name, address]
        );
    res.status(201).json(result.rows[0]);
    } catch (error) {
        console.error('Error inserting store:', error);
        res.status(500).json({ message: 'Internal Server Error' });
    }
}

exports.getID = async function getID(req, res) {
    try {
        const { id } = req.params;
      const response = await pg.query("SELECT * FROM stores WHERE id = $1", [id]);

      return res.status(200).json(response.rows[0]);
    } catch (error) {
        res.status(500).json({message: "Store not found"});
    }
};

exports.updateStore = async function updateStore(req, res) {
    try {
        const { id } = req.body;
        const { name, address } = req.body;
        const response = await pg.query("UPDATE stores SET name = $1, address = $2 WHERE id = $3", [name, address, id]);
        
        //res.json(name, address);

        res.status(200).json({ message: "Store updated successfully" });
    } catch (error) {
        res.status(500).json({message: "Update Store Failed"});
    }
}

exports.deleteStore = async function deleteStore(req, res){
    try{
        const {id} = req.params;
        const response = await pg.query("DELETE FROM stores WHERE id = $1", [id]);
    if (response.rowCount === 0) {
        return res.status(404).json({ error: "Store not found" });
    }
    res.status(200).json({message: "Store deleted successfully"});
} catch (error) {
    res.status(500).json({message: "Delete Store Unsuccesful"});
}
}

exports.register = async function register(req, res){


    if (!req.query.email || !req.query.password || !req.query.name) {
        return res.status(400).json({ message: 'Tidak boleh kosong!' });
    }

    try {
        const result = await pg.query(
            'INSERT INTO users(name, email, password) VALUES($1, $2, $3) RETURNING *',
            [req.query.name, req.query.email, req.query.password]
        );
    res.status(201).json(result.rows[0]);
    } catch (error) {
        console.error('Error inserting user:', error);
        res.status(500).json({ message: 'Fail to register' });
    }
}


exports.login = async function login(req, res){
    if (!req.query.email || !req.query.password) {
        return res.status(400).json({ message: 'Tidak boleh kosong!' });
    }

    try {
        const result = await pg.query(
            'SELECT * FROM users WHERE email = $1 and password = $2',
            [req.query.email, req.query.password]
        );
    if(result.rowCount == 0){
        return res.status(400).json({ message: 'Email atau password salah' });
    }
    res.status(201).json(result.rows[0]);
    } catch (error) {
        res.status(500).json({ message: 'Fail to login' });
    }
}

exports.getEmail = async function getEmail(req, res) {
    try {
        const { email } = req.params;
      const response = await pg.query("SELECT * FROM users WHERE email = $1", [email]);

      if(response.rowCount === 0){
            return res.status(404).json({message: "User not found"});
        }

      return res.status(200).json(response.rows[0]);
    } catch (error) {
        res.status(500).json(error);
    }
};

exports.updateUser = async function updateUser(req, res) {
    try {
        const { email, password, name, id } = req.body;
        const response = await pg.query("UPDATE users SET email = $1, password = $2, name = $3 WHERE id = $4", [email, password, name, id]);
        
        //res.json(name, address);

        if(response.rowCount === 0){
            return res.status(404).json({message: "User not found"});
        }

        res.status(200).json({ message: "User data updated successfully" });
    } catch (error) {
        res.status(500).json({message: "fail to update user"});
    }
}

exports.deleteUser = async function deleteUser(req, res){
    try{
        const response = await pg.query("DELETE FROM users WHERE id = $1", [req.params.id]);
        if (response.rowCount === 0) {
            return res.status(404).json({ error: "User not found" });
        } else {
            return res.status(200).json({ message: "User deleted successfully" });
        }
    } catch (error) {
        res.status(500).json({message: "Internal Server Error"});
    }
}

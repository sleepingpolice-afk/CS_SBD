const express = require("express");
const router = express.Router();
const controller = require("./controller"); 

// Define the routes
router.post("/create", controller.createTransaction);
router.post("/pay/:id", controller.payTransaction);
router.delete("/:id", controller.deleteTransaction);

module.exports = router;